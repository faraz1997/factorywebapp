#!/bin/bash

# Factory ERP System - Installation Script
# This script automates the installation process

echo "=========================================="
echo "Factory ERP System - Installation"
echo "=========================================="
echo ""

# Check Python version
echo "Checking Python version..."
python_version=$(python3 --version 2>&1 | grep -oP '\d+\.\d+')
if (( $(echo "$python_version >= 3.8" | bc -l) )); then
    echo "✓ Python $python_version detected"
else
    echo "✗ Python 3.8 or higher required. Current: $python_version"
    exit 1
fi

echo ""
echo "Installing dependencies..."
pip3 install Flask Flask-SQLAlchemy Flask-Login --quiet --user

if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed successfully"
else
    echo "✗ Failed to install dependencies"
    echo "  Try manually: pip3 install Flask Flask-SQLAlchemy Flask-Login"
    exit 1
fi

echo ""
echo "=========================================="
echo "Installation Complete!"
echo "=========================================="
echo ""
echo "To start the application:"
echo "  1. cd factory_erp"
echo "  2. python3 run.py"
echo "  3. Open http://localhost:5000 in your browser"
echo ""
echo "Login Credentials:"
echo "  Admin: admin / admin123"
echo "  Staff: staff1 / staff123"
echo ""
echo "For more information, see README.md or QUICK_START.md"
echo "=========================================="
