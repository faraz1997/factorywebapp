# Factory ERP System - Features Overview

## 🎯 Core Capabilities

### 1. PRODUCTION MANAGEMENT
**Daily Production Entry**
- Date selection with calendar picker
- Dropdown for product category (Washing Machine / Cooler / Dryer)
- Auto-filtered product models based on category
- Quantity input with validation
- Worker/Fitter dropdown selection
- Optional notes field
- Real-time validation before submission

**What Happens on Submit:**
✓ Checks if sufficient raw materials available
✓ Validates quantity > 0
✓ Deducts raw materials automatically (based on recipe × quantity)
✓ Adds finished goods to inventory
✓ Records transaction with timestamp and user
✓ Updates all dashboards in real-time
✓ Creates audit trail

**Production Entry List:**
- View recent 10 production entries
- See date, product, quantity, worker
- Admin can delete entries (reverses all transactions)
- Staff can only view

---

### 2. PRODUCT RECIPES (BOM - BILL OF MATERIALS)
**Recipe Management**
- Create recipe for each product model
- Select product model from dropdown
- Add multiple raw materials
- Specify quantity per unit (e.g., 1 motor for 1 washing machine)
- Edit existing recipes
- View all recipes organized by category

**Recipe Display:**
- Grouped by product category
- Shows all required materials
- Displays quantity per unit
- Unit of measurement for each material
- Edit button for admin users

**Example Recipe:**
```
WM-7KG-Auto (Washing Machine)
├── WM Motor: 1 pcs
├── WM Drum: 1 pcs
├── Control Panel: 1 pcs
├── WM Body Shell: 1 pcs
├── Water Pump: 1 pcs
├── Power Cord: 1 pcs
├── Screws Set: 2 set
└── Packaging Box: 1 pcs
```

---

### 3. RAW MATERIAL MANAGEMENT
**Inventory Tracking**
- Category-wise organization (WM Parts, Cooler Parts, Dryer Parts, Common Parts)
- Real-time stock calculation
- Low stock threshold per material (configurable)
- Color-coded status indicators:
  * Green = In Stock
  * Yellow = Low Stock (below threshold)
  * Red = Out of Stock (0 or negative)

**Stock Transactions:**
- **IN (Add Stock)**: Purchase orders, receiving materials
- **OUT (Remove Stock)**: Manual adjustments, wastage
- **PRODUCTION**: Automatic deduction when production recorded

**Features:**
- View current stock for all materials
- Add stock (IN) with reference and notes
- Remove stock (OUT) with reason
- View complete transaction history
- Running balance calculation
- User tracking for all transactions

**Transaction History:**
- Date and time of each transaction
- Transaction type (IN/OUT/PRODUCTION)
- Quantity moved
- Running balance after transaction
- Reference (PO number, production entry #)
- User who made the transaction

---

### 4. FINISHED GOODS INVENTORY
**Stock Management**
- Model-wise stock tracking
- Category-wise summary
- Real-time balance calculation
- Automatic IN from production
- Manual OUT for dispatch

**Stock Transactions:**
- **IN**: Automatic from production entries
- **OUT**: Manual dispatch with order reference

**Display:**
- Category badge (color-coded)
- Product model name
- Current stock quantity
- Dispatch button (admin only)

---

### 5. DASHBOARD 1 - PRODUCTION OVERVIEW
**Key Metrics (Stat Cards):**
- Today's Production (total units)
- This Week's Production
- This Month's Production
- Total Product Lines

**Today's Production by Category:**
- Washing Machines: X units
- Coolers: Y units
- Dryers: Z units

**Finished Goods Stock Summary:**
- Category-wise totals
- Quick view of available inventory

**Recent Production Entries:**
- Last 5 production records
- Date, product, quantity, worker
- Quick access to recent activity

**Model-wise Stock:**
- Individual product model stock levels
- Category tags
- Stock badges with quantities

---

### 6. DASHBOARD 2 - INVENTORY & ALERTS
**Alert Summary (Stat Cards):**
- Healthy Stock Count (Green)
- Low Stock Count (Yellow)
- Critical Stock Count (Red)
- Total Materials Count

**Critical Stock Alert Box:**
- Red danger alert
- Lists materials critically low
- Shows current quantity
- Urgent attention required

**Low Stock Warning Box:**
- Yellow warning alert
- Lists materials below threshold
- Shows current vs threshold
- Planning required

**Category-wise Stock Tables:**
- Organized by material category
- Shows material name
- Current stock quantity
- Low stock threshold
- Visual progress bar (stock level %)
- Status badge (OK/LOW/CRITICAL)
- Row highlighting (red for critical, yellow for low)

---

### 7. WORKER / FITTER MANAGEMENT
**Worker List:**
- Name and Employee ID
- Active/Inactive status badge
- Edit and toggle buttons
- Clean table layout

**Add Worker:**
- Name field
- Employee ID field (unique)
- Validation for duplicates
- Success message on save

**Edit Worker:**
- Update name
- Update employee ID
- Check for conflicts
- Maintain production history

**Toggle Status:**
- Activate/Deactivate workers
- Inactive workers don't appear in production dropdown
- Preserves historical data

---

### 8. REPORTS
**Production Report:**
- Date range filter (start date to end date)
- Category filter (all or specific)
- Product model filter (optional)
- Total production quantity
- Category-wise breakdown
- Product-wise breakdown with entry count
- Detailed entry list

**Raw Material Usage Report:**
- Date range filter
- Material-specific filter (optional)
- Transaction type summary (IN/OUT/PRODUCTION)
- Material-wise usage breakdown
- Recent 50 transactions list
- Date, material, type, quantity, reference

**Worker Productivity Report:**
- Date range filter
- Worker ranking by total units
- Total entries per worker
- Category-wise breakdown per worker
- Badge display for different categories
- Sorted by productivity (highest first)

---

### 9. ADMIN FUNCTIONS
**Materials Setup:**
- View all raw materials by category
- Add new raw material
- Edit existing materials
- Set low stock thresholds
- Configure units of measurement

**Products Setup:**
- View all product models by category
- Add new product models
- Edit existing models
- Add descriptions
- Organize by category

**Access Control:**
- Only admin users can access
- Staff users redirected with message
- Decorator-based protection

---

### 10. AUTHENTICATION & SECURITY
**Login System:**
- Username and password authentication
- Role-based access (admin/staff)
- Session management
- Remember user between requests
- Logout functionality

**Role-Based Access Control:**
- Admin: Full access to all features
- Staff: Production entry only, view-only for most features
- Delete restricted to admin
- Stock adjustments restricted to admin
- Configuration changes restricted to admin

**Security Features:**
- Password hashing (werkzeug)
- Session-based authentication
- Protected routes with @login_required
- Role checking with @admin_required
- CSRF protection (Flask default)

---

## 🎨 USER INTERFACE FEATURES

### Design Elements:
- **Modern Gradient Cards**: Colorful stat cards with gradients
- **Responsive Layout**: Works on desktop, tablet, mobile
- **Bootstrap 5**: Professional, clean design
- **Bootstrap Icons**: Consistent iconography
- **Color Coding**: 
  * Blue for primary actions
  * Green for success/positive
  * Yellow for warnings
  * Red for critical/danger
  * Purple/gradient for visual appeal

### Navigation:
- **Sidebar Menu**: Persistent left sidebar
- **Active Highlighting**: Current page highlighted
- **User Info**: Username and role displayed
- **Icon Menu Items**: Visual identification
- **Grouped Sections**: Logical organization

### Forms:
- **Validation**: Client and server-side
- **Dropdowns**: Prevents typos, ensures consistency
- **Date Pickers**: HTML5 date inputs
- **Number Inputs**: Min/max validation
- **Text Areas**: For notes and descriptions
- **Submit Buttons**: Clear, action-oriented

### Tables:
- **Responsive**: Scrollable on small screens
- **Striped Rows**: Easy to read
- **Header Styling**: Clear column labels
- **Badges**: Status indicators
- **Action Buttons**: Inline actions
- **Row Highlighting**: Status-based colors

### Alerts & Messages:
- **Flash Messages**: Success, error, warning, info
- **Auto-dismiss**: Close button
- **Color Coded**: Bootstrap alert classes
- **Icon Support**: Visual indicators
- **Positioned Top**: Immediate visibility

---

## 🔄 DATA FLOW

### Production Entry Flow:
```
User Input
    ↓
Validation (Qty > 0, Recipe exists, Stock sufficient)
    ↓
Create Production Entry Record
    ↓
For each material in recipe:
    - Calculate total needed (recipe qty × production qty)
    - Create RawMaterialTransaction (PRODUCTION, OUT)
    ↓
Create FinishedGoodsStock (IN)
    ↓
Commit all to database (atomic transaction)
    ↓
Success message + redirect
    ↓
Dashboards auto-update (real-time calculation)
```

### Stock Calculation Flow:
```
Get Material ID
    ↓
Query all RawMaterialTransaction for this material
    ↓
Initialize balance = 0
    ↓
For each transaction:
    - If type = IN: balance += quantity
    - If type = OUT or PRODUCTION: balance -= quantity
    ↓
Return current balance
```

---

## 📊 SAMPLE DATA STRUCTURE

### Pre-loaded Data:
- 3 Users (1 admin, 2 staff)
- 3 Product Categories
- 8 Product Models
- 4 Raw Material Categories
- 18 Raw Materials with stock
- 5 Workers
- Complete recipes for main products
- Sample production entries with history

### Database Tables:
- users (3 rows)
- product_categories (3 rows)
- product_models (8 rows)
- product_recipes (~32 rows)
- raw_material_categories (4 rows)
- raw_materials (18 rows)
- raw_material_transactions (~18+ rows)
- workers (5 rows)
- production_entries (sample data)
- finished_goods_stock (sample data)

---

## 🚀 TECHNICAL HIGHLIGHTS

1. **Atomic Transactions**: All or nothing - if production fails, nothing is saved
2. **Real-time Calculations**: Stock calculated on-the-fly, always accurate
3. **Audit Trail**: Every transaction tracked with user and timestamp
4. **Cascading Deletes**: Delete production entry = reverse all related transactions
5. **Foreign Key Integrity**: Database enforces relationships
6. **Responsive Queries**: Efficient database queries with joins
7. **Template Filters**: Custom date/time formatting
8. **Flash Messages**: User feedback for all actions
9. **Form Validation**: Both client and server side
10. **Clean Code**: Organized, modular, maintainable

---

This system provides everything needed to manage a manufacturing factory's production and inventory efficiently! 🏭
