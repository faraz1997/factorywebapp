# init_db.py
from app import create_app, db
from app.models.seed_data import seed_database

app = create_app()

with app.app_context():
    # Drop all tables (fresh start)
    db.drop_all()
    
    # Create all tables
    db.create_all()
    
    # Seed data
    seed_database()
    
    print("✓ Database initialized successfully!")

if __name__ == '__main__':
    pass
