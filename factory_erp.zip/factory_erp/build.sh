#!/usr/bin/env bash
# build.sh

set -o errexit

# Install dependencies
pip install -r requirements.txt

# Create instance directory
mkdir -p instance

# Initialize database
python init_db.py