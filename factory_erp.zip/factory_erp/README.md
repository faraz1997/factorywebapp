# Factory ERP System - Production & Inventory Management

A complete production and inventory management web application for a manufacturing factory that produces Washing Machines, Coolers, and Dryer Machines.

## Features

### 1. Authentication & Authorization
- **Admin**: Full access to all features
- **Staff**: Production entry only, no delete access

### 2. Production Management
- Daily production entry with automatic inventory updates
- Category-based product selection (Washing Machine / Cooler / Dryer)
- Model-wise production tracking
- Worker/Fitter assignment
- Automatic raw material deduction based on BOM
- Automatic finished goods stock increase

### 3. Product Recipe (Bill of Materials)
- Create and manage product recipes
- Define raw materials required per unit
- Category-wise material organization
- Link recipes to product models

### 4. Raw Material Management
- Category-wise organization (WM Parts / Cooler Parts / Dryer Parts)
- Stock IN transactions (purchases)
- Stock OUT transactions (manual adjustments)
- Automatic deduction on production
- Real-time stock calculation
- Low stock threshold alerts
- Transaction history tracking

### 5. Finished Goods Inventory
- Auto-add stock from production
- Manual dispatch (OUT transactions)
- Model-wise stock view
- Category-wise stock summary

### 6. Dashboards

**Dashboard 1 - Production Overview:**
- Today's production summary
- Weekly and monthly production totals
- Category-wise production breakdown
- Finished goods stock summary
- Recent production entries
- Model-wise stock levels

**Dashboard 2 - Inventory & Alerts:**
- Raw material stock status
- Low stock warnings (highlighted in yellow)
- Critical stock alerts (highlighted in red)
- Category-wise stock tables
- Stock level visualization with progress bars
- Healthy/Low/Critical stock counts

### 7. Worker Management (Admin Only)
- Add/edit workers
- Toggle active status
- View in production dropdown

### 8. Reports
- **Production Report**: Date-wise and product-wise analysis
- **Raw Material Usage Report**: Track material consumption
- **Worker Productivity Report**: Performance metrics by worker

## Tech Stack

- **Backend**: Python Flask 3.0.0
- **Database**: SQLite (with SQLAlchemy ORM)
- **Frontend**: Bootstrap 5.3.0
- **Authentication**: Flask-Login
- **Icons**: Bootstrap Icons

## Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Installation Steps

1. **Extract and navigate to the project directory:**
```bash
cd factory_erp
```

2. **Create a virtual environment (recommended):**
```bash
python -m venv venv

# On Windows:
venv\Scripts\activate

# On Linux/Mac:
source venv/bin/activate
```

3. **Install required packages:**
```bash
pip install -r requirements.txt
```

4. **Run the application:**
```bash
python run.py
```

5. **Access the application:**
Open your web browser and navigate to:
```
http://localhost:5000
```

## Default Login Credentials

### Administrator Account
- **Username**: `admin`
- **Password**: `admin123`
- **Access**: Full system access

### Staff Account
- **Username**: `staff1`
- **Password**: `staff123`
- **Access**: Production entry only

## Database Structure

The application automatically creates the following database structure:

### Core Tables:
- **users**: User accounts and roles
- **product_categories**: Washing Machine, Cooler, Dryer
- **product_models**: Specific product models
- **product_recipes**: Bill of Materials (BOM)
- **raw_material_categories**: Material groupings
- **raw_materials**: Individual materials with stock tracking
- **raw_material_transactions**: All material movements
- **workers**: Factory workers/fitters
- **production_entries**: Daily production records
- **finished_goods_stock**: Finished product inventory

### Sample Data Included:

**Product Categories:**
- Washing Machines
- Coolers
- Dryers

**Sample Product Models:**
- WM-7KG-Auto, WM-8KG-Semi, WM-10KG-Auto
- Desert-50L, Desert-70L, Personal-20L
- Dryer-6KG, Dryer-8KG

**Sample Raw Materials:**
- WM Parts: Motors, Drums, Control Panels, Pumps, Body Shells
- Cooler Parts: Motors, Cooling Pads, Water Tanks, Blowers
- Dryer Parts: Motors, Drums, Heating Elements, Drive Belts
- Common Parts: Power Cords, Screws, Packaging

**Sample Workers:**
- Ahmed Khan (EMP001)
- Bilal Ahmed (EMP002)
- Farhan Ali (EMP003)
- Hassan Raza (EMP004)
- Imran Shah (EMP005)

## Key Workflows

### Adding Production Entry:
1. Select production date
2. Choose product category
3. Select product model (auto-filtered)
4. Enter quantity produced
5. Select worker
6. Submit → System automatically:
   - Deducts raw materials per recipe
   - Adds to finished goods stock
   - Creates audit trail

### Managing Raw Materials:
1. **Add Stock (IN)**: Purchase or receive materials
2. **Remove Stock (OUT)**: Manual adjustments
3. **View Transactions**: Complete history with running balance
4. **Monitor Alerts**: Dashboard shows low/critical stock

### Creating Product Recipes:
1. Navigate to Product Recipes
2. Click "Create Recipe"
3. Select product model
4. Add raw materials with quantities
5. Save → Recipe used in production calculations

## Project Structure

```
factory_erp/
├── app/
│   ├── __init__.py              # Flask app initialization
│   ├── models/                  # Database models
│   │   ├── user.py
│   │   ├── product.py
│   │   ├── raw_material.py
│   │   ├── production.py
│   │   └── seed_data.py
│   ├── routes/                  # Application routes
│   │   ├── auth.py              # Authentication
│   │   ├── production.py        # Production management
│   │   ├── inventory.py         # Inventory management
│   │   ├── dashboard.py         # Dashboards
│   │   ├── reports.py           # Reports
│   │   └── admin.py             # Admin functions
│   ├── templates/               # HTML templates
│   │   ├── base.html
│   │   ├── auth/
│   │   ├── production/
│   │   ├── inventory/
│   │   ├── dashboard/
│   │   ├── reports/
│   │   └── admin/
│   └── static/                  # Static files (CSS, JS)
├── instance/                    # Database file location
├── requirements.txt             # Python dependencies
├── run.py                       # Application entry point
└── README.md                    # This file
```

## Important Notes

### Role-Based Access:
- **Admin**: Can delete production entries, manage workers, add/remove stock
- **Staff**: Can only add production entries, cannot delete

### Stock Management:
- All stock calculations are real-time
- Production automatically deducts materials
- Low stock thresholds can be configured per material
- Transaction history maintained for audit

### Data Consistency:
- Foreign key relationships ensure data integrity
- Cascade deletes for dependent records
- Transaction-based operations for consistency

### Performance:
- SQLite suitable for single-factory deployment
- Can be upgraded to PostgreSQL/MySQL for multi-factory
- Indexes on frequently queried fields

## Customization

### Change Secret Key:
Edit `app/__init__.py`:
```python
app.config['SECRET_KEY'] = 'your-secure-secret-key'
```

### Change Database:
Edit `app/__init__.py`:
```python
app.config['SQLALCHEMY_DATABASE_URI'] = 'your-database-url'
```

### Add New Product Categories:
1. Use admin interface or
2. Add directly in seed_data.py

### Modify Low Stock Thresholds:
- Navigate to Admin → Materials Setup
- Edit individual materials
- Set appropriate threshold values

## Troubleshooting

### Port Already in Use:
Change port in `run.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

### Database Issues:
Delete `instance/factory.db` and restart to recreate with seed data

### Permission Errors:
Ensure write permissions in project directory for database file

## Security Considerations

**For Production Deployment:**
1. Change default passwords immediately
2. Use strong secret key
3. Enable HTTPS
4. Use production-grade database (PostgreSQL)
5. Set `debug=False` in run.py
6. Implement proper backup strategy
7. Add user management features
8. Implement session timeout
9. Add input validation and sanitization
10. Use environment variables for sensitive config

## Support & Maintenance

### Database Backup:
```bash
# Backup SQLite database
cp instance/factory.db instance/factory_backup_$(date +%Y%m%d).db
```

### Logs:
Flask debug mode shows errors in console
For production, implement proper logging

## License

This project is provided as-is for educational and commercial use.

## Version

**Version 1.0.0** - Initial Release
- Complete production management
- Inventory tracking with alerts
- Role-based access control
- Comprehensive reporting
- Sample data for testing

---

**Developed for manufacturing factory management**
Built with Flask, Bootstrap, and SQLAlchemy
