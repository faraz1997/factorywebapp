# QUICK START GUIDE - Factory ERP System

## What You Have

A complete Production & Inventory Management System for a manufacturing factory with:
- ✅ Full authentication system (Admin & Staff roles)
- ✅ Production entry with automatic inventory updates
- ✅ Product recipes (Bill of Materials)
- ✅ Raw material management with alerts
- ✅ Finished goods inventory
- ✅ 2 Comprehensive dashboards
- ✅ Worker management
- ✅ Detailed reports
- ✅ Sample data pre-loaded

## Installation (Simple 3 Steps)

### Step 1: Install Dependencies
```bash
pip install Flask Flask-SQLAlchemy Flask-Login
```

Or if you get permission errors:
```bash
pip install Flask Flask-SQLAlchemy Flask-Login --user
```

### Step 2: Run the Application
```bash
cd factory_erp
python run.py
```

### Step 3: Open in Browser
```
http://localhost:5000
```

## Login Credentials

**Admin Account (Full Access):**
- Username: `admin`
- Password: `admin123`

**Staff Account (Production Entry Only):**
- Username: `staff1`
- Password: `staff123`

## Key Features Tour

### 1. Production Entry (Main Feature)
- Go to: Production Entry menu
- Select date, category, product model, quantity, worker
- Click "Add Production Entry"
- **Magic happens**: Raw materials auto-deducted, finished goods auto-added!

### 2. View Inventory Alerts
- Go to: Inventory Alerts Dashboard
- See which materials are low or critical
- Color-coded warnings (Yellow = Low, Red = Critical)

### 3. Check Production Stats
- Go to: Production Dashboard
- See today's, week's, and month's production
- View stock levels by category

### 4. Manage Raw Materials (Admin Only)
- Go to: Raw Materials menu
- Click "Add Stock (IN)" to purchase materials
- View transaction history for any material

### 5. Create Product Recipes
- Go to: Product Recipes
- Click "Create Recipe"
- Select product and add required materials
- Quantities are per 1 unit of product

### 6. Generate Reports
- Go to: Reports menu
- Production Report: Filter by date/category
- Raw Material Usage: Track consumption
- Worker Productivity: See performance

## Sample Data Included

✅ 3 Product Categories (Washing Machine, Cooler, Dryer)
✅ 8 Product Models
✅ 18 Raw Materials with initial stock
✅ 5 Workers
✅ Product recipes already configured
✅ Sample production entries

## Common Tasks

### Add New Worker
1. Login as admin
2. Go to: Manage Workers
3. Click "Add Worker"
4. Enter name and employee ID

### Add New Raw Material
1. Login as admin
2. Go to: Materials Setup
3. Click "Add Material"
4. Enter details and set low stock threshold

### Record Production
1. Go to: Production Entry
2. Fill in all fields
3. Submit
4. System automatically handles inventory!

### Dispatch Finished Goods
1. Go to: Finished Goods
2. Click "Dispatch Goods"
3. Select product and quantity
4. Enter order reference

## File Structure

```
factory_erp/
├── README.md              ← Comprehensive documentation
├── QUICK_START.md         ← This file
├── requirements.txt       ← Python packages needed
├── run.py                 ← Start application
├── app/
│   ├── __init__.py
│   ├── models/            ← Database models
│   ├── routes/            ← Application logic
│   └── templates/         ← HTML pages
└── instance/
    └── factory.db         ← SQLite database (auto-created)
```

## Troubleshooting

**Problem**: Port 5000 already in use
**Solution**: Edit run.py, change port to 5001 or 8080

**Problem**: Module not found errors
**Solution**: Install packages: `pip install Flask Flask-SQLAlchemy Flask-Login`

**Problem**: Database errors
**Solution**: Delete `instance/factory.db` and restart (recreates with sample data)

**Problem**: Login not working
**Solution**: Use exact credentials: admin/admin123 or staff1/staff123

## What Makes This Special?

🚀 **Automatic Inventory**: Production entry automatically deducts materials and adds finished goods
📊 **Real-time Alerts**: Dashboard shows low stock with color coding
👥 **Role-Based Access**: Admin can do everything, Staff can only add production
🔄 **Complete Audit Trail**: Every transaction recorded with user and timestamp
📱 **Responsive Design**: Works on desktop, tablet, and mobile
🎨 **Professional UI**: Clean Bootstrap design with modern gradients

## Next Steps

1. **Customize Products**: Add your actual product models and categories
2. **Configure Materials**: Add your raw materials with proper thresholds
3. **Add Workers**: Enter your factory workers
4. **Create Recipes**: Define BOM for each product
5. **Start Using**: Begin recording daily production!

## Security Notes

⚠️ **Important for Production Use**:
1. Change admin password immediately
2. Change SECRET_KEY in app/__init__.py
3. Use PostgreSQL instead of SQLite for production
4. Enable HTTPS
5. Set debug=False in run.py

## Support

For detailed documentation, see README.md
For questions about features, check the comprehensive README

## Credits

Built with:
- Flask (Python web framework)
- Bootstrap 5 (Responsive UI)
- SQLite (Database)
- SQLAlchemy (ORM)

---

**Ready to manage your factory production? Just run `python run.py` and you're good to go!** 🏭
