import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from datetime import datetime

db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    
    # Configuration
    # Use environment variable or default
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Database configuration for Render
    database_url = os.environ.get('DATABASE_URL')
    if database_url:
        # Render provides DATABASE_URL
        app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    else:
        # Local development
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///factory.db'
    
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    
    # Register blueprints
    from app.routes import auth, production, inventory, dashboard, reports, admin, partners
    
    app.register_blueprint(auth.bp)
    app.register_blueprint(production.bp)
    app.register_blueprint(inventory.bp)
    app.register_blueprint(dashboard.bp)
    app.register_blueprint(reports.bp)
    app.register_blueprint(admin.bp)
    app.register_blueprint(partners.bp)
    
    # Template filters
    @app.template_filter('datetime')
    def format_datetime(value):
        if value is None:
            return ''
        if isinstance(value, str):
            value = datetime.fromisoformat(value)
        return value.strftime('%Y-%m-%d %H:%M')
    
    @app.template_filter('date')
    def format_date(value):
        if value is None:
            return ''
        if isinstance(value, str):
            value = datetime.fromisoformat(value)
        return value.strftime('%Y-%m-%d')
    
    return app
