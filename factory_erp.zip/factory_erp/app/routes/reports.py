from flask import Blueprint, render_template, request
from flask_login import login_required
from app.models.product import ProductCategory, ProductModel
from app.models.production import ProductionEntry
from app.models.raw_material import RawMaterialTransaction, RawMaterial
from datetime import datetime, date, timedelta

bp = Blueprint('reports', __name__, url_prefix='/reports')

@bp.route('/production')
@login_required
def production_report():
    """Date-wise and product-wise production report"""
    
    # Get date range from query params
    end_date = request.args.get('end_date')
    start_date = request.args.get('start_date')
    product_model_id = request.args.get('product_model_id')
    category_id = request.args.get('category_id')
    
    # Default to last 30 days
    if not end_date:
        end_date = date.today()
    else:
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    
    if not start_date:
        start_date = end_date - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
    
    # Build query
    query = ProductionEntry.query.filter(
        ProductionEntry.production_date >= start_date,
        ProductionEntry.production_date <= end_date
    )
    
    # Filter by product model if specified
    if product_model_id:
        query = query.filter_by(product_model_id=int(product_model_id))
    
    # Filter by category if specified
    if category_id:
        category_id = int(category_id)
        model_ids = [m.id for m in ProductModel.query.filter_by(category_id=category_id).all()]
        query = query.filter(ProductionEntry.product_model_id.in_(model_ids))
    
    # Get production entries
    production_entries = query.order_by(ProductionEntry.production_date.desc()).all()
    
    # Calculate totals
    total_quantity = sum(p.quantity_produced for p in production_entries)
    
    # Product-wise summary
    product_summary = {}
    for entry in production_entries:
        model_name = entry.product_model.name
        if model_name not in product_summary:
            product_summary[model_name] = {
                'category': entry.product_model.category.name,
                'quantity': 0,
                'entries': 0
            }
        product_summary[model_name]['quantity'] += entry.quantity_produced
        product_summary[model_name]['entries'] += 1
    
    # Category-wise summary
    category_summary = {}
    for entry in production_entries:
        cat_name = entry.product_model.category.name
        if cat_name not in category_summary:
            category_summary[cat_name] = 0
        category_summary[cat_name] += entry.quantity_produced
    
    # Get all categories and models for filter
    categories = ProductCategory.query.all()
    models = ProductModel.query.all()
    
    return render_template('reports/production.html',
                         production_entries=production_entries,
                         total_quantity=total_quantity,
                         product_summary=product_summary,
                         category_summary=category_summary,
                         start_date=start_date,
                         end_date=end_date,
                         categories=categories,
                         models=models,
                         selected_category_id=category_id,
                         selected_model_id=product_model_id)

@bp.route('/raw-material-usage')
@login_required
def raw_material_usage():
    """Raw material usage report"""
    
    # Get date range from query params
    end_date = request.args.get('end_date')
    start_date = request.args.get('start_date')
    material_id = request.args.get('material_id')
    
    # Default to last 30 days
    if not end_date:
        end_date = datetime.now()
    else:
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
    
    if not start_date:
        start_date = end_date - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
    
    # Build query
    query = RawMaterialTransaction.query.filter(
        RawMaterialTransaction.transaction_date >= start_date,
        RawMaterialTransaction.transaction_date <= end_date
    )
    
    # Filter by material if specified
    if material_id:
        query = query.filter_by(raw_material_id=int(material_id))
    
    # Get transactions
    transactions = query.order_by(RawMaterialTransaction.transaction_date.desc()).all()
    
    # Calculate summaries
    usage_summary = {}  # Material-wise usage
    type_summary = {'IN': 0, 'OUT': 0, 'PRODUCTION': 0}  # Transaction type summary
    
    for trans in transactions:
        material_name = trans.raw_material.name
        
        # Material-wise summary
        if material_name not in usage_summary:
            usage_summary[material_name] = {
                'IN': 0,
                'OUT': 0,
                'PRODUCTION': 0,
                'unit': trans.raw_material.unit
            }
        
        usage_summary[material_name][trans.transaction_type] += trans.quantity
        type_summary[trans.transaction_type] += trans.quantity
    
    # Get all materials for filter
    materials = RawMaterial.query.all()
    
    return render_template('reports/raw_material_usage.html',
                         transactions=transactions,
                         usage_summary=usage_summary,
                         type_summary=type_summary,
                         start_date=start_date.date(),
                         end_date=end_date.date(),
                         materials=materials,
                         selected_material_id=material_id)

@bp.route('/worker-productivity')
@login_required
def worker_productivity():
    """Worker productivity report"""
    from app.models.production import Worker
    
    # Get date range
    end_date = request.args.get('end_date')
    start_date = request.args.get('start_date')
    
    if not end_date:
        end_date = date.today()
    else:
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    
    if not start_date:
        start_date = end_date - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
    
    # Get all workers
    workers = Worker.query.filter_by(is_active=True).all()
    
    worker_stats = []
    for worker in workers:
        entries = ProductionEntry.query.filter(
            ProductionEntry.worker_id == worker.id,
            ProductionEntry.production_date >= start_date,
            ProductionEntry.production_date <= end_date
        ).all()
        
        total_units = sum(e.quantity_produced for e in entries)
        total_entries = len(entries)
        
        # Category-wise breakdown
        category_breakdown = {}
        for entry in entries:
            cat_name = entry.product_model.category.name
            if cat_name not in category_breakdown:
                category_breakdown[cat_name] = 0
            category_breakdown[cat_name] += entry.quantity_produced
        
        worker_stats.append({
            'worker': worker,
            'total_units': total_units,
            'total_entries': total_entries,
            'category_breakdown': category_breakdown
        })
    
    # Sort by total units
    worker_stats.sort(key=lambda x: x['total_units'], reverse=True)
    
    return render_template('reports/worker_productivity.html',
                         worker_stats=worker_stats,
                         start_date=start_date,
                         end_date=end_date)
