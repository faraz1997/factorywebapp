from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.models.business_partners import Supplier, Customer, PurchaseOrder, PurchaseOrderItem, SalesOrder, SalesOrderItem
from app.models.raw_material import RawMaterial, RawMaterialTransaction
from app.models.product import ProductModel
from app.models.production import FinishedGoodsStock
from datetime import datetime, date

bp = Blueprint('partners', __name__, url_prefix='/partners')

def admin_required(f):
    """Decorator to require admin role"""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin():
            flash('You need administrator privileges to access this page', 'danger')
            return redirect(url_for('dashboard.production_overview'))
        return f(*args, **kwargs)
    return decorated_function

# ============ SUPPLIERS ============

@bp.route('/suppliers')
@login_required
def suppliers():
    """List all suppliers"""
    suppliers = Supplier.query.order_by(Supplier.name).all()
    return render_template('partners/suppliers.html', suppliers=suppliers)

@bp.route('/supplier/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_supplier():
    """Add new supplier"""
    if request.method == 'POST':
        try:
            supplier = Supplier(
                name=request.form.get('name'),
                company_name=request.form.get('company_name'),
                contact_person=request.form.get('contact_person'),
                phone=request.form.get('phone'),
                email=request.form.get('email'),
                address=request.form.get('address'),
                city=request.form.get('city'),
                country=request.form.get('country', 'Pakistan'),
                tax_id=request.form.get('tax_id'),
                payment_terms=request.form.get('payment_terms'),
                credit_limit=float(request.form.get('credit_limit', 0)),
                rating=int(request.form.get('rating', 5)),
                notes=request.form.get('notes')
            )
            db.session.add(supplier)
            db.session.commit()
            
            flash(f'Supplier {supplier.name} added successfully', 'success')
            return redirect(url_for('partners.suppliers'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding supplier: {str(e)}', 'danger')
    
    return render_template('partners/add_supplier.html')

@bp.route('/supplier/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_supplier(id):
    """Edit supplier details"""
    supplier = Supplier.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            supplier.name = request.form.get('name')
            supplier.company_name = request.form.get('company_name')
            supplier.contact_person = request.form.get('contact_person')
            supplier.phone = request.form.get('phone')
            supplier.email = request.form.get('email')
            supplier.address = request.form.get('address')
            supplier.city = request.form.get('city')
            supplier.country = request.form.get('country', 'Pakistan')
            supplier.tax_id = request.form.get('tax_id')
            supplier.payment_terms = request.form.get('payment_terms')
            supplier.credit_limit = float(request.form.get('credit_limit', 0))
            supplier.rating = int(request.form.get('rating', 5))
            supplier.notes = request.form.get('notes')
            
            db.session.commit()
            
            flash(f'Supplier {supplier.name} updated successfully', 'success')
            return redirect(url_for('partners.suppliers'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating supplier: {str(e)}', 'danger')
    
    return render_template('partners/edit_supplier.html', supplier=supplier)

@bp.route('/supplier/toggle/<int:id>')
@login_required
@admin_required
def toggle_supplier(id):
    """Toggle supplier active status"""
    try:
        supplier = Supplier.query.get_or_404(id)
        supplier.is_active = not supplier.is_active
        db.session.commit()
        
        status = 'activated' if supplier.is_active else 'deactivated'
        flash(f'Supplier {supplier.name} {status} successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating supplier status: {str(e)}', 'danger')
    
    return redirect(url_for('partners.suppliers'))

@bp.route('/supplier/view/<int:id>')
@login_required
def view_supplier(id):
    """View supplier details and purchase history"""
    supplier = Supplier.query.get_or_404(id)
    purchase_orders = PurchaseOrder.query.filter_by(supplier_id=id).order_by(PurchaseOrder.order_date.desc()).all()
    return render_template('partners/view_supplier.html', supplier=supplier, purchase_orders=purchase_orders)

# ============ CUSTOMERS ============

@bp.route('/customers')
@login_required
def customers():
    """List all customers"""
    customers = Customer.query.order_by(Customer.name).all()
    return render_template('partners/customers.html', customers=customers)

@bp.route('/customer/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_customer():
    """Add new customer"""
    if request.method == 'POST':
        try:
            customer = Customer(
                name=request.form.get('name'),
                company_name=request.form.get('company_name'),
                contact_person=request.form.get('contact_person'),
                phone=request.form.get('phone'),
                email=request.form.get('email'),
                address=request.form.get('address'),
                city=request.form.get('city'),
                country=request.form.get('country', 'Pakistan'),
                tax_id=request.form.get('tax_id'),
                payment_terms=request.form.get('payment_terms'),
                credit_limit=float(request.form.get('credit_limit', 0)),
                customer_type=request.form.get('customer_type', 'Retail'),
                notes=request.form.get('notes')
            )
            db.session.add(customer)
            db.session.commit()
            
            flash(f'Customer {customer.name} added successfully', 'success')
            return redirect(url_for('partners.customers'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding customer: {str(e)}', 'danger')
    
    return render_template('partners/add_customer.html')

@bp.route('/customer/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_customer(id):
    """Edit customer details"""
    customer = Customer.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            customer.name = request.form.get('name')
            customer.company_name = request.form.get('company_name')
            customer.contact_person = request.form.get('contact_person')
            customer.phone = request.form.get('phone')
            customer.email = request.form.get('email')
            customer.address = request.form.get('address')
            customer.city = request.form.get('city')
            customer.country = request.form.get('country', 'Pakistan')
            customer.tax_id = request.form.get('tax_id')
            customer.payment_terms = request.form.get('payment_terms')
            customer.credit_limit = float(request.form.get('credit_limit', 0))
            customer.customer_type = request.form.get('customer_type', 'Retail')
            customer.notes = request.form.get('notes')
            
            db.session.commit()
            
            flash(f'Customer {customer.name} updated successfully', 'success')
            return redirect(url_for('partners.customers'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating customer: {str(e)}', 'danger')
    
    return render_template('partners/edit_customer.html', customer=customer)

@bp.route('/customer/toggle/<int:id>')
@login_required
@admin_required
def toggle_customer(id):
    """Toggle customer active status"""
    try:
        customer = Customer.query.get_or_404(id)
        customer.is_active = not customer.is_active
        db.session.commit()
        
        status = 'activated' if customer.is_active else 'deactivated'
        flash(f'Customer {customer.name} {status} successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating customer status: {str(e)}', 'danger')
    
    return redirect(url_for('partners.customers'))

@bp.route('/customer/view/<int:id>')
@login_required
def view_customer(id):
    """View customer details and sales history"""
    customer = Customer.query.get_or_404(id)
    sales_orders = SalesOrder.query.filter_by(customer_id=id).order_by(SalesOrder.order_date.desc()).all()
    return render_template('partners/view_customer.html', customer=customer, sales_orders=sales_orders)

# ============ PURCHASE ORDERS ============

@bp.route('/purchase-orders')
@login_required
def purchase_orders():
    """List all purchase orders"""
    orders = PurchaseOrder.query.order_by(PurchaseOrder.order_date.desc()).all()
    return render_template('partners/purchase_orders.html', orders=orders)

@bp.route('/purchase-order/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_purchase_order():
    """Create new purchase order"""
    if request.method == 'POST':
        try:
            # Generate PO number
            last_po = PurchaseOrder.query.order_by(PurchaseOrder.id.desc()).first()
            po_number = f'PO-{(last_po.id + 1):05d}' if last_po else 'PO-00001'
            
            order_date = datetime.strptime(request.form.get('order_date'), '%Y-%m-%d').date()
            expected_delivery = request.form.get('expected_delivery')
            if expected_delivery:
                expected_delivery = datetime.strptime(expected_delivery, '%Y-%m-%d').date()
            
            po = PurchaseOrder(
                po_number=po_number,
                supplier_id=int(request.form.get('supplier_id')),
                order_date=order_date,
                expected_delivery=expected_delivery,
                notes=request.form.get('notes'),
                user_id=current_user.id
            )
            db.session.add(po)
            db.session.flush()
            
            # Add items
            material_ids = request.form.getlist('material_id[]')
            quantities = request.form.getlist('quantity[]')
            unit_prices = request.form.getlist('unit_price[]')
            
            total_amount = 0
            for mat_id, qty, price in zip(material_ids, quantities, unit_prices):
                if mat_id and qty and price:
                    qty = float(qty)
                    price = float(price)
                    total = qty * price
                    
                    item = PurchaseOrderItem(
                        purchase_order_id=po.id,
                        raw_material_id=int(mat_id),
                        quantity=qty,
                        unit_price=price,
                        total_price=total
                    )
                    db.session.add(item)
                    total_amount += total
            
            po.total_amount = total_amount
            db.session.commit()
            
            flash(f'Purchase Order {po_number} created successfully', 'success')
            return redirect(url_for('partners.purchase_orders'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error creating purchase order: {str(e)}', 'danger')
    
    suppliers = Supplier.query.filter_by(is_active=True).all()
    materials = RawMaterial.query.all()
    return render_template('partners/add_purchase_order.html', suppliers=suppliers, materials=materials)

@bp.route('/purchase-order/receive/<int:id>')
@login_required
@admin_required
def receive_purchase_order(id):
    """Mark purchase order as received and add stock"""
    try:
        po = PurchaseOrder.query.get_or_404(id)
        
        if po.status == 'Received':
            flash('This purchase order has already been received', 'warning')
            return redirect(url_for('partners.purchase_orders'))
        
        # Add stock for each item
        for item in po.items:
            transaction = RawMaterialTransaction(
                raw_material_id=item.raw_material_id,
                transaction_type='IN',
                quantity=item.quantity,
                reference=f'PO {po.po_number}',
                notes=f'Received from {po.supplier.name}',
                user_id=current_user.id
            )
            db.session.add(transaction)
        
        po.status = 'Received'
        db.session.commit()
        
        flash(f'Purchase Order {po.po_number} received and stock updated', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error receiving purchase order: {str(e)}', 'danger')
    
    return redirect(url_for('partners.purchase_orders'))

# ============ SALES ORDERS ============

@bp.route('/sales-orders')
@login_required
def sales_orders():
    """List all sales orders"""
    orders = SalesOrder.query.order_by(SalesOrder.order_date.desc()).all()
    return render_template('partners/sales_orders.html', orders=orders)

@bp.route('/sales-order/add', methods=['GET', 'POST'])
@login_required
def add_sales_order():
    """Create new sales order"""
    if request.method == 'POST':
        try:
            # Generate SO number
            last_so = SalesOrder.query.order_by(SalesOrder.id.desc()).first()
            so_number = f'SO-{(last_so.id + 1):05d}' if last_so else 'SO-00001'
            
            order_date = datetime.strptime(request.form.get('order_date'), '%Y-%m-%d').date()
            delivery_date = request.form.get('delivery_date')
            if delivery_date:
                delivery_date = datetime.strptime(delivery_date, '%Y-%m-%d').date()
            
            so = SalesOrder(
                so_number=so_number,
                customer_id=int(request.form.get('customer_id')),
                order_date=order_date,
                delivery_date=delivery_date,
                notes=request.form.get('notes'),
                user_id=current_user.id
            )
            db.session.add(so)
            db.session.flush()
            
            # Add items
            product_ids = request.form.getlist('product_id[]')
            quantities = request.form.getlist('quantity[]')
            unit_prices = request.form.getlist('unit_price[]')
            
            total_amount = 0
            for prod_id, qty, price in zip(product_ids, quantities, unit_prices):
                if prod_id and qty and price:
                    qty = int(qty)
                    price = float(price)
                    total = qty * price
                    
                    item = SalesOrderItem(
                        sales_order_id=so.id,
                        product_model_id=int(prod_id),
                        quantity=qty,
                        unit_price=price,
                        total_price=total
                    )
                    db.session.add(item)
                    total_amount += total
            
            so.total_amount = total_amount
            db.session.commit()
            
            flash(f'Sales Order {so_number} created successfully', 'success')
            return redirect(url_for('partners.sales_orders'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error creating sales order: {str(e)}', 'danger')
    
    customers = Customer.query.filter_by(is_active=True).all()
    products = ProductModel.query.all()
    return render_template('partners/add_sales_order.html', customers=customers, products=products)

@bp.route('/sales-order/dispatch/<int:id>')
@login_required
@admin_required
def dispatch_sales_order(id):
    """Mark sales order as dispatched and deduct stock"""
    try:
        so = SalesOrder.query.get_or_404(id)
        
        if so.status in ['Dispatched', 'Delivered']:
            flash('This sales order has already been dispatched', 'warning')
            return redirect(url_for('partners.sales_orders'))
        
        # Check stock availability
        for item in so.items:
            current_stock = FinishedGoodsStock.get_current_stock(item.product_model_id)
            if current_stock < item.quantity:
                flash(f'Insufficient stock for {item.product_model.name}. Available: {current_stock}, Required: {item.quantity}', 'danger')
                return redirect(url_for('partners.sales_orders'))
        
        # Deduct stock for each item
        for item in so.items:
            transaction = FinishedGoodsStock(
                product_model_id=item.product_model_id,
                transaction_type='OUT',
                quantity=item.quantity,
                reference=f'SO {so.so_number}',
                notes=f'Dispatched to {so.customer.name}',
                user_id=current_user.id
            )
            db.session.add(transaction)
        
        so.status = 'Dispatched'
        db.session.commit()
        
        flash(f'Sales Order {so.so_number} dispatched and stock updated', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error dispatching sales order: {str(e)}', 'danger')
    
    return redirect(url_for('partners.sales_orders'))
