from flask import Blueprint, render_template
from flask_login import login_required
from app.models.product import ProductCategory, ProductModel
from app.models.production import ProductionEntry, FinishedGoodsStock
from app.models.raw_material import RawMaterial, RawMaterialCategory
from datetime import date, timedelta
from sqlalchemy import func

bp = Blueprint('dashboard', __name__, url_prefix='/dashboard')

@bp.route('/production-overview')
@login_required
def production_overview():
    """Dashboard 1 - Production Overview"""
    today = date.today()
    
    # Today's production summary
    today_production = ProductionEntry.query.filter_by(production_date=today).all()
    today_total = sum(p.quantity_produced for p in today_production)
    
    # Category-wise today's production
    category_production = {}
    for category in ProductCategory.query.all():
        total = 0
        for prod in today_production:
            if prod.product_model.category_id == category.id:
                total += prod.quantity_produced
        category_production[category.name] = total
    
    # This week's production
    week_start = today - timedelta(days=today.weekday())
    week_production = ProductionEntry.query.filter(
        ProductionEntry.production_date >= week_start
    ).all()
    week_total = sum(p.quantity_produced for p in week_production)
    
    # This month's production
    month_start = today.replace(day=1)
    month_production = ProductionEntry.query.filter(
        ProductionEntry.production_date >= month_start
    ).all()
    month_total = sum(p.quantity_produced for p in month_production)
    
    # Finished goods stock summary
    finished_goods_summary = []
    for category in ProductCategory.query.all():
        category_stock = 0
        for model in category.models:
            stock = FinishedGoodsStock.get_current_stock(model.id)
            category_stock += stock
        finished_goods_summary.append({
            'category': category.name,
            'stock': category_stock
        })
    
    # Recent production entries
    recent_production = ProductionEntry.query.order_by(
        ProductionEntry.production_date.desc(),
        ProductionEntry.created_at.desc()
    ).limit(5).all()
    
    # Model-wise stock
    model_stock = []
    for model in ProductModel.query.all():
        stock = FinishedGoodsStock.get_current_stock(model.id)
        if stock > 0:
            model_stock.append({
                'model': model.name,
                'category': model.category.name,
                'stock': stock
            })
    
    return render_template('dashboard/production_overview.html',
                         today_total=today_total,
                         week_total=week_total,
                         month_total=month_total,
                         category_production=category_production,
                         finished_goods_summary=finished_goods_summary,
                         recent_production=recent_production,
                         model_stock=model_stock,
                         today=today)

@bp.route('/inventory-alerts')
@login_required
def inventory_alerts():
    """Dashboard 2 - Inventory & Alerts"""
    
    # Get all raw materials with stock info
    materials_data = []
    low_stock_materials = []
    critical_stock_materials = []
    
    for category in RawMaterialCategory.query.all():
        category_materials = []
        for material in category.raw_materials:
            current_stock = material.get_current_stock()
            is_low = material.is_low_stock()
            is_critical = current_stock <= (material.low_stock_threshold * 0.5)
            
            material_info = {
                'material': material,
                'current_stock': current_stock,
                'is_low': is_low,
                'is_critical': is_critical,
                'stock_percentage': (current_stock / material.low_stock_threshold * 100) if material.low_stock_threshold > 0 else 100
            }
            
            category_materials.append(material_info)
            
            if is_critical:
                critical_stock_materials.append(material_info)
            elif is_low:
                low_stock_materials.append(material_info)
        
        materials_data.append({
            'category': category,
            'materials': category_materials
        })
    
    # Count materials by status
    total_materials = RawMaterial.query.count()
    low_stock_count = len(low_stock_materials)
    critical_stock_count = len(critical_stock_materials)
    healthy_stock_count = total_materials - low_stock_count - critical_stock_count
    
    return render_template('dashboard/inventory_alerts.html',
                         materials_data=materials_data,
                         low_stock_materials=low_stock_materials,
                         critical_stock_materials=critical_stock_materials,
                         total_materials=total_materials,
                         low_stock_count=low_stock_count,
                         critical_stock_count=critical_stock_count,
                         healthy_stock_count=healthy_stock_count)
