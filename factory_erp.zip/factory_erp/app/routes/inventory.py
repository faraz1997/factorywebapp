from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.models.raw_material import RawMaterialCategory, RawMaterial, RawMaterialTransaction
from app.models.product import ProductModel
from app.models.production import FinishedGoodsStock

bp = Blueprint('inventory', __name__, url_prefix='/inventory')

@bp.route('/raw-materials')
@login_required
def raw_materials():
    """View all raw materials with current stock"""
    categories = RawMaterialCategory.query.all()
    materials_data = []
    
    for category in categories:
        for material in category.raw_materials:
            current_stock = material.get_current_stock()
            materials_data.append({
                'material': material,
                'category': category,
                'current_stock': current_stock,
                'is_low': material.is_low_stock()
            })
    
    return render_template('inventory/raw_materials.html', materials_data=materials_data)

@bp.route('/raw-material/add-stock', methods=['GET', 'POST'])
@login_required
def add_raw_material_stock():
    """Add raw material stock (IN transaction)"""
    if not current_user.is_admin():
        flash('Only administrators can add raw material stock', 'danger')
        return redirect(url_for('inventory.raw_materials'))
    
    if request.method == 'POST':
        try:
            raw_material_id = int(request.form.get('raw_material_id'))
            quantity = float(request.form.get('quantity'))
            reference = request.form.get('reference', 'Manual Entry')
            notes = request.form.get('notes', '')
            
            if quantity <= 0:
                flash('Quantity must be greater than 0', 'danger')
                return redirect(url_for('inventory.add_raw_material_stock'))
            
            transaction = RawMaterialTransaction(
                raw_material_id=raw_material_id,
                transaction_type='IN',
                quantity=quantity,
                reference=reference,
                notes=notes,
                user_id=current_user.id
            )
            db.session.add(transaction)
            db.session.commit()
            
            material = RawMaterial.query.get(raw_material_id)
            flash(f'Stock added successfully! {quantity} {material.unit} of {material.name}', 'success')
            return redirect(url_for('inventory.raw_materials'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding stock: {str(e)}', 'danger')
    
    materials = RawMaterial.query.all()
    return render_template('inventory/add_stock.html', materials=materials)

@bp.route('/raw-material/remove-stock', methods=['GET', 'POST'])
@login_required
def remove_raw_material_stock():
    """Remove raw material stock (OUT transaction)"""
    if not current_user.is_admin():
        flash('Only administrators can remove raw material stock', 'danger')
        return redirect(url_for('inventory.raw_materials'))
    
    if request.method == 'POST':
        try:
            raw_material_id = int(request.form.get('raw_material_id'))
            quantity = float(request.form.get('quantity'))
            reference = request.form.get('reference', 'Manual Adjustment')
            notes = request.form.get('notes', '')
            
            if quantity <= 0:
                flash('Quantity must be greater than 0', 'danger')
                return redirect(url_for('inventory.remove_raw_material_stock'))
            
            material = RawMaterial.query.get(raw_material_id)
            current_stock = material.get_current_stock()
            
            if current_stock < quantity:
                flash(f'Insufficient stock! Available: {current_stock} {material.unit}', 'danger')
                return redirect(url_for('inventory.remove_raw_material_stock'))
            
            transaction = RawMaterialTransaction(
                raw_material_id=raw_material_id,
                transaction_type='OUT',
                quantity=quantity,
                reference=reference,
                notes=notes,
                user_id=current_user.id
            )
            db.session.add(transaction)
            db.session.commit()
            
            flash(f'Stock removed successfully! {quantity} {material.unit} of {material.name}', 'success')
            return redirect(url_for('inventory.raw_materials'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error removing stock: {str(e)}', 'danger')
    
    materials = RawMaterial.query.all()
    return render_template('inventory/remove_stock.html', materials=materials)

@bp.route('/finished-goods')
@login_required
def finished_goods():
    """View finished goods stock"""
    models = ProductModel.query.all()
    stock_data = []
    
    for model in models:
        current_stock = FinishedGoodsStock.get_current_stock(model.id)
        stock_data.append({
            'model': model,
            'category': model.category,
            'current_stock': current_stock
        })
    
    return render_template('inventory/finished_goods.html', stock_data=stock_data)

@bp.route('/finished-goods/dispatch', methods=['GET', 'POST'])
@login_required
def dispatch_finished_goods():
    """Dispatch finished goods (OUT transaction)"""
    if not current_user.is_admin():
        flash('Only administrators can dispatch finished goods', 'danger')
        return redirect(url_for('inventory.finished_goods'))
    
    if request.method == 'POST':
        try:
            product_model_id = int(request.form.get('product_model_id'))
            quantity = int(request.form.get('quantity'))
            reference = request.form.get('reference', 'Manual Dispatch')
            notes = request.form.get('notes', '')
            
            if quantity <= 0:
                flash('Quantity must be greater than 0', 'danger')
                return redirect(url_for('inventory.dispatch_finished_goods'))
            
            current_stock = FinishedGoodsStock.get_current_stock(product_model_id)
            
            if current_stock < quantity:
                flash(f'Insufficient stock! Available: {current_stock} units', 'danger')
                return redirect(url_for('inventory.dispatch_finished_goods'))
            
            transaction = FinishedGoodsStock(
                product_model_id=product_model_id,
                transaction_type='OUT',
                quantity=quantity,
                reference=reference,
                notes=notes,
                user_id=current_user.id
            )
            db.session.add(transaction)
            db.session.commit()
            
            model = ProductModel.query.get(product_model_id)
            flash(f'Dispatched successfully! {quantity} units of {model.name}', 'success')
            return redirect(url_for('inventory.finished_goods'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error dispatching goods: {str(e)}', 'danger')
    
    models = ProductModel.query.all()
    return render_template('inventory/dispatch.html', models=models)

@bp.route('/transactions/<int:material_id>')
@login_required
def material_transactions(material_id):
    """View transaction history for a raw material"""
    material = RawMaterial.query.get_or_404(material_id)
    transactions = RawMaterialTransaction.query.filter_by(raw_material_id=material_id).order_by(RawMaterialTransaction.transaction_date.desc()).all()
    
    # Calculate running balance
    balance = 0
    transactions_with_balance = []
    for t in reversed(transactions):
        if t.transaction_type == 'IN':
            balance += t.quantity
        elif t.transaction_type in ['OUT', 'PRODUCTION']:
            balance -= t.quantity
        transactions_with_balance.append({
            'transaction': t,
            'balance': balance
        })
    
    transactions_with_balance.reverse()
    
    return render_template('inventory/transactions.html', material=material, transactions=transactions_with_balance)
