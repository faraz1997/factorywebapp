from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app import db
from app.models.product import ProductCategory, ProductModel, ProductRecipe
from app.models.production import Worker, ProductionEntry, FinishedGoodsStock
from app.models.raw_material import RawMaterial, RawMaterialTransaction
from datetime import datetime

bp = Blueprint('production', __name__, url_prefix='/production')

@bp.route('/')
@login_required
def index():
    """Production entry page"""
    categories = ProductCategory.query.all()
    workers = Worker.query.filter_by(is_active=True).all()
    recent_entries = ProductionEntry.query.order_by(ProductionEntry.created_at.desc()).limit(10).all()
    return render_template('production/index.html', categories=categories, workers=workers, recent_entries=recent_entries)

@bp.route('/get-models/<int:category_id>')
@login_required
def get_models(category_id):
    """API endpoint to get models by category"""
    models = ProductModel.query.filter_by(category_id=category_id).all()
    return jsonify([{'id': m.id, 'name': m.name} for m in models])

@bp.route('/add', methods=['POST'])
@login_required
def add_production():
    """Add new production entry"""
    try:
        production_date = datetime.strptime(request.form.get('production_date'), '%Y-%m-%d').date()
        product_model_id = int(request.form.get('product_model_id'))
        quantity = int(request.form.get('quantity'))
        worker_id = int(request.form.get('worker_id'))
        notes = request.form.get('notes', '')
        
        # Validate quantity
        if quantity <= 0:
            flash('Quantity must be greater than 0', 'danger')
            return redirect(url_for('production.index'))
        
        # Get product recipe
        recipes = ProductRecipe.query.filter_by(product_model_id=product_model_id).all()
        
        if not recipes:
            flash('No recipe found for this product model. Please create a recipe first.', 'warning')
            return redirect(url_for('production.index'))
        
        # Check if sufficient raw materials are available
        insufficient_materials = []
        for recipe in recipes:
            required_qty = recipe.quantity_per_unit * quantity
            current_stock = recipe.raw_material.get_current_stock()
            
            if current_stock < required_qty:
                insufficient_materials.append(f"{recipe.raw_material.name} (Required: {required_qty}, Available: {current_stock})")
        
        if insufficient_materials:
            flash('Insufficient raw materials: ' + ', '.join(insufficient_materials), 'danger')
            return redirect(url_for('production.index'))
        
        # Create production entry
        production = ProductionEntry(
            production_date=production_date,
            product_model_id=product_model_id,
            quantity_produced=quantity,
            worker_id=worker_id,
            user_id=current_user.id,
            notes=notes
        )
        db.session.add(production)
        db.session.flush()  # Get production ID
        
        # Deduct raw materials
        for recipe in recipes:
            total_qty = recipe.quantity_per_unit * quantity
            transaction = RawMaterialTransaction(
                raw_material_id=recipe.raw_material_id,
                transaction_type='PRODUCTION',
                quantity=total_qty,
                reference=f'Production #{production.id}',
                user_id=current_user.id
            )
            db.session.add(transaction)
        
        # Add finished goods stock
        finished_goods = FinishedGoodsStock(
            product_model_id=product_model_id,
            transaction_type='IN',
            quantity=quantity,
            reference=f'Production #{production.id}',
            user_id=current_user.id
        )
        db.session.add(finished_goods)
        
        db.session.commit()
        
        product_model = ProductModel.query.get(product_model_id)
        flash(f'Production entry added successfully! {quantity} units of {product_model.name} produced.', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding production entry: {str(e)}', 'danger')
    
    return redirect(url_for('production.index'))

@bp.route('/delete/<int:id>')
@login_required
def delete_production(id):
    """Delete production entry (admin only)"""
    if not current_user.is_admin():
        flash('Only administrators can delete production entries', 'danger')
        return redirect(url_for('production.index'))
    
    try:
        production = ProductionEntry.query.get_or_404(id)
        
        # Delete related transactions
        RawMaterialTransaction.query.filter_by(reference=f'Production #{id}').delete()
        FinishedGoodsStock.query.filter_by(reference=f'Production #{id}').delete()
        
        db.session.delete(production)
        db.session.commit()
        
        flash('Production entry deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting production entry: {str(e)}', 'danger')
    
    return redirect(url_for('production.index'))

@bp.route('/recipes')
@login_required
def recipes():
    """View all product recipes"""
    models = ProductModel.query.all()
    return render_template('production/recipes.html', models=models)

@bp.route('/recipe/add', methods=['GET', 'POST'])
@login_required
def add_recipe():
    """Add/Edit product recipe (admin only)"""
    if not current_user.is_admin():
        flash('Only administrators can manage recipes', 'danger')
        return redirect(url_for('production.recipes'))
    
    if request.method == 'POST':
        try:
            product_model_id = int(request.form.get('product_model_id'))
            
            # Delete existing recipes for this product
            ProductRecipe.query.filter_by(product_model_id=product_model_id).delete()
            
            # Add new recipes
            raw_material_ids = request.form.getlist('raw_material_id[]')
            quantities = request.form.getlist('quantity[]')
            
            for rm_id, qty in zip(raw_material_ids, quantities):
                if rm_id and qty:
                    recipe = ProductRecipe(
                        product_model_id=product_model_id,
                        raw_material_id=int(rm_id),
                        quantity_per_unit=float(qty)
                    )
                    db.session.add(recipe)
            
            db.session.commit()
            flash('Recipe saved successfully', 'success')
            return redirect(url_for('production.recipes'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error saving recipe: {str(e)}', 'danger')
    
    models = ProductModel.query.all()
    raw_materials = RawMaterial.query.all()
    return render_template('production/add_recipe.html', models=models, raw_materials=raw_materials)

@bp.route('/recipe/edit/<int:model_id>')
@login_required
def edit_recipe(model_id):
    """Edit existing recipe"""
    if not current_user.is_admin():
        flash('Only administrators can manage recipes', 'danger')
        return redirect(url_for('production.recipes'))
    
    model = ProductModel.query.get_or_404(model_id)
    models = ProductModel.query.all()
    raw_materials = RawMaterial.query.all()
    existing_recipes = ProductRecipe.query.filter_by(product_model_id=model_id).all()
    
    return render_template('production/add_recipe.html', 
                         models=models, 
                         raw_materials=raw_materials,
                         selected_model=model,
                         existing_recipes=existing_recipes)
