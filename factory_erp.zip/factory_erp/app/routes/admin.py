from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.models.production import Worker
from app.models.raw_material import RawMaterial, RawMaterialCategory
from app.models.product import ProductCategory, ProductModel

bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    """Decorator to require admin role"""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin():
            flash('You need administrator privileges to access this page', 'danger')
            return redirect(url_for('dashboard.production_overview'))
        return f(*args, **kwargs)
    return decorated_function

@bp.route('/workers')
@login_required
@admin_required
def workers():
    """Manage workers"""
    workers = Worker.query.all()
    return render_template('admin/workers.html', workers=workers)

@bp.route('/worker/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_worker():
    """Add new worker"""
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            employee_id = request.form.get('employee_id')
            
            # Check if employee_id already exists
            existing = Worker.query.filter_by(employee_id=employee_id).first()
            if existing:
                flash('Employee ID already exists', 'danger')
                return redirect(url_for('admin.add_worker'))
            
            worker = Worker(name=name, employee_id=employee_id)
            db.session.add(worker)
            db.session.commit()
            
            flash(f'Worker {name} added successfully', 'success')
            return redirect(url_for('admin.workers'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding worker: {str(e)}', 'danger')
    
    return render_template('admin/add_worker.html')

@bp.route('/worker/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_worker(id):
    """Edit worker details"""
    worker = Worker.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            worker.name = request.form.get('name')
            employee_id = request.form.get('employee_id')
            
            # Check if employee_id already exists for another worker
            existing = Worker.query.filter_by(employee_id=employee_id).first()
            if existing and existing.id != worker.id:
                flash('Employee ID already exists', 'danger')
                return redirect(url_for('admin.edit_worker', id=id))
            
            worker.employee_id = employee_id
            db.session.commit()
            
            flash(f'Worker {worker.name} updated successfully', 'success')
            return redirect(url_for('admin.workers'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating worker: {str(e)}', 'danger')
    
    return render_template('admin/edit_worker.html', worker=worker)

@bp.route('/worker/toggle/<int:id>')
@login_required
@admin_required
def toggle_worker(id):
    """Toggle worker active status"""
    try:
        worker = Worker.query.get_or_404(id)
        worker.is_active = not worker.is_active
        db.session.commit()
        
        status = 'activated' if worker.is_active else 'deactivated'
        flash(f'Worker {worker.name} {status} successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating worker status: {str(e)}', 'danger')
    
    return redirect(url_for('admin.workers'))

@bp.route('/raw-materials-setup')
@login_required
@admin_required
def raw_materials_setup():
    """Manage raw materials and categories"""
    categories = RawMaterialCategory.query.all()
    return render_template('admin/raw_materials_setup.html', categories=categories)

@bp.route('/raw-material/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_raw_material():
    """Add new raw material"""
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            category_id = int(request.form.get('category_id'))
            unit = request.form.get('unit')
            low_stock_threshold = float(request.form.get('low_stock_threshold', 10))
            
            material = RawMaterial(
                name=name,
                category_id=category_id,
                unit=unit,
                low_stock_threshold=low_stock_threshold
            )
            db.session.add(material)
            db.session.commit()
            
            flash(f'Raw material {name} added successfully', 'success')
            return redirect(url_for('admin.raw_materials_setup'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding raw material: {str(e)}', 'danger')
    
    categories = RawMaterialCategory.query.all()
    return render_template('admin/add_raw_material.html', categories=categories)

@bp.route('/raw-material/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_raw_material(id):
    """Edit raw material"""
    material = RawMaterial.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            material.name = request.form.get('name')
            material.category_id = int(request.form.get('category_id'))
            material.unit = request.form.get('unit')
            material.low_stock_threshold = float(request.form.get('low_stock_threshold', 10))
            
            db.session.commit()
            
            flash(f'Raw material {material.name} updated successfully', 'success')
            return redirect(url_for('admin.raw_materials_setup'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating raw material: {str(e)}', 'danger')
    
    categories = RawMaterialCategory.query.all()
    return render_template('admin/edit_raw_material.html', material=material, categories=categories)

@bp.route('/products-setup')
@login_required
@admin_required
def products_setup():
    """Manage product models"""
    categories = ProductCategory.query.all()
    return render_template('admin/products_setup.html', categories=categories)

@bp.route('/product/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_product():
    """Add new product model"""
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            category_id = int(request.form.get('category_id'))
            description = request.form.get('description', '')
            
            product = ProductModel(
                name=name,
                category_id=category_id,
                description=description
            )
            db.session.add(product)
            db.session.commit()
            
            flash(f'Product model {name} added successfully', 'success')
            return redirect(url_for('admin.products_setup'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding product: {str(e)}', 'danger')
    
    categories = ProductCategory.query.all()
    return render_template('admin/add_product.html', categories=categories)

@bp.route('/product/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_product(id):
    """Edit product model"""
    product = ProductModel.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            product.name = request.form.get('name')
            product.category_id = int(request.form.get('category_id'))
            product.description = request.form.get('description', '')
            
            db.session.commit()
            
            flash(f'Product model {product.name} updated successfully', 'success')
            return redirect(url_for('admin.products_setup'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating product: {str(e)}', 'danger')
    
    categories = ProductCategory.query.all()
    return render_template('admin/edit_product.html', product=product, categories=categories)
