from app import db
from app.models.user import User
from app.models.product import ProductCategory, ProductModel, ProductRecipe
from app.models.raw_material import RawMaterialCategory, RawMaterial, RawMaterialTransaction
from app.models.production import Worker, ProductionEntry, FinishedGoodsStock
from datetime import datetime, date, timedelta

def seed_database():
    """Seed the database with initial data if empty"""
    
    # Check if already seeded
    if User.query.first() is not None:
        return
    
    print("Seeding database...")
    
    # Create Users
    admin = User(username='admin', role='admin')
    admin.set_password('admin123')
    
    staff1 = User(username='staff1', role='staff')
    staff1.set_password('staff123')
    
    staff2 = User(username='staff2', role='staff')
    staff2.set_password('staff123')
    
    db.session.add_all([admin, staff1, staff2])
    
    # Create Product Categories
    wm_cat = ProductCategory(name='Washing Machine')
    cooler_cat = ProductCategory(name='Cooler')
    dryer_cat = ProductCategory(name='Dryer')
    
    db.session.add_all([wm_cat, cooler_cat, dryer_cat])
    db.session.commit()
    
    # Create Product Models
    # Washing Machines
    wm_model1 = ProductModel(name='WM-7KG-Auto', category_id=wm_cat.id, description='7KG Automatic Washing Machine')
    wm_model2 = ProductModel(name='WM-8KG-Semi', category_id=wm_cat.id, description='8KG Semi-Automatic Washing Machine')
    wm_model3 = ProductModel(name='WM-10KG-Auto', category_id=wm_cat.id, description='10KG Automatic Washing Machine')
    
    # Coolers
    cooler_model1 = ProductModel(name='Desert-50L', category_id=cooler_cat.id, description='50 Liter Desert Cooler')
    cooler_model2 = ProductModel(name='Desert-70L', category_id=cooler_cat.id, description='70 Liter Desert Cooler')
    cooler_model3 = ProductModel(name='Personal-20L', category_id=cooler_cat.id, description='20 Liter Personal Cooler')
    
    # Dryers
    dryer_model1 = ProductModel(name='Dryer-6KG', category_id=dryer_cat.id, description='6KG Capacity Dryer')
    dryer_model2 = ProductModel(name='Dryer-8KG', category_id=dryer_cat.id, description='8KG Capacity Dryer')
    
    db.session.add_all([wm_model1, wm_model2, wm_model3, cooler_model1, cooler_model2, cooler_model3, dryer_model1, dryer_model2])
    db.session.commit()
    
    # Create Raw Material Categories
    wm_parts = RawMaterialCategory(name='WM Parts')
    cooler_parts = RawMaterialCategory(name='Cooler Parts')
    dryer_parts = RawMaterialCategory(name='Dryer Parts')
    common_parts = RawMaterialCategory(name='Common Parts')
    
    db.session.add_all([wm_parts, cooler_parts, dryer_parts, common_parts])
    db.session.commit()
    
    # Create Raw Materials
    # WM Parts
    wm_motor = RawMaterial(name='WM Motor', category_id=wm_parts.id, unit='pcs', low_stock_threshold=10)
    wm_drum = RawMaterial(name='WM Drum', category_id=wm_parts.id, unit='pcs', low_stock_threshold=5)
    wm_panel = RawMaterial(name='Control Panel', category_id=wm_parts.id, unit='pcs', low_stock_threshold=10)
    wm_body = RawMaterial(name='WM Body Shell', category_id=wm_parts.id, unit='pcs', low_stock_threshold=8)
    wm_pump = RawMaterial(name='Water Pump', category_id=wm_parts.id, unit='pcs', low_stock_threshold=10)
    
    # Cooler Parts
    cooler_motor = RawMaterial(name='Cooler Motor', category_id=cooler_parts.id, unit='pcs', low_stock_threshold=10)
    cooler_pad = RawMaterial(name='Cooling Pads', category_id=cooler_parts.id, unit='pcs', low_stock_threshold=20)
    cooler_tank = RawMaterial(name='Water Tank', category_id=cooler_parts.id, unit='pcs', low_stock_threshold=10)
    cooler_body = RawMaterial(name='Cooler Body', category_id=cooler_parts.id, unit='pcs', low_stock_threshold=8)
    cooler_blower = RawMaterial(name='Air Blower', category_id=cooler_parts.id, unit='pcs', low_stock_threshold=12)
    
    # Dryer Parts
    dryer_motor = RawMaterial(name='Dryer Motor', category_id=dryer_parts.id, unit='pcs', low_stock_threshold=8)
    dryer_drum = RawMaterial(name='Dryer Drum', category_id=dryer_parts.id, unit='pcs', low_stock_threshold=5)
    dryer_heater = RawMaterial(name='Heating Element', category_id=dryer_parts.id, unit='pcs', low_stock_threshold=10)
    dryer_body = RawMaterial(name='Dryer Body Shell', category_id=dryer_parts.id, unit='pcs', low_stock_threshold=5)
    dryer_belt = RawMaterial(name='Drive Belt', category_id=dryer_parts.id, unit='pcs', low_stock_threshold=15)
    
    # Common Parts
    power_cord = RawMaterial(name='Power Cord', category_id=common_parts.id, unit='pcs', low_stock_threshold=20)
    screws = RawMaterial(name='Screws Set', category_id=common_parts.id, unit='set', low_stock_threshold=30)
    packaging = RawMaterial(name='Packaging Box', category_id=common_parts.id, unit='pcs', low_stock_threshold=25)
    
    db.session.add_all([
        wm_motor, wm_drum, wm_panel, wm_body, wm_pump,
        cooler_motor, cooler_pad, cooler_tank, cooler_body, cooler_blower,
        dryer_motor, dryer_drum, dryer_heater, dryer_body, dryer_belt,
        power_cord, screws, packaging
    ])
    db.session.commit()
    
    # Create Product Recipes (BOM)
    # WM-7KG-Auto Recipe
    recipes = [
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=wm_motor.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=wm_drum.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=wm_panel.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=wm_body.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=wm_pump.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=power_cord.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=screws.id, quantity_per_unit=2),
        ProductRecipe(product_model_id=wm_model1.id, raw_material_id=packaging.id, quantity_per_unit=1),
        
        # WM-8KG-Semi Recipe
        ProductRecipe(product_model_id=wm_model2.id, raw_material_id=wm_motor.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model2.id, raw_material_id=wm_drum.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model2.id, raw_material_id=wm_body.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model2.id, raw_material_id=wm_pump.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model2.id, raw_material_id=power_cord.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=wm_model2.id, raw_material_id=screws.id, quantity_per_unit=2),
        ProductRecipe(product_model_id=wm_model2.id, raw_material_id=packaging.id, quantity_per_unit=1),
        
        # Desert-50L Cooler Recipe
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=cooler_motor.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=cooler_pad.id, quantity_per_unit=4),
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=cooler_tank.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=cooler_body.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=cooler_blower.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=power_cord.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=screws.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=cooler_model1.id, raw_material_id=packaging.id, quantity_per_unit=1),
        
        # Dryer-6KG Recipe
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=dryer_motor.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=dryer_drum.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=dryer_heater.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=dryer_body.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=dryer_belt.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=power_cord.id, quantity_per_unit=1),
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=screws.id, quantity_per_unit=2),
        ProductRecipe(product_model_id=dryer_model1.id, raw_material_id=packaging.id, quantity_per_unit=1),
    ]
    
    db.session.add_all(recipes)
    db.session.commit()
    
    # Create Workers
    workers = [
        Worker(name='Ahmed Khan', employee_id='EMP001'),
        Worker(name='Bilal Ahmed', employee_id='EMP002'),
        Worker(name='Farhan Ali', employee_id='EMP003'),
        Worker(name='Hassan Raza', employee_id='EMP004'),
        Worker(name='Imran Shah', employee_id='EMP005'),
    ]
    
    db.session.add_all(workers)
    db.session.commit()
    
    # Add Initial Raw Material Stock
    initial_stock = [
        # WM Parts
        RawMaterialTransaction(raw_material_id=wm_motor.id, transaction_type='IN', quantity=100, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=wm_drum.id, transaction_type='IN', quantity=80, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=wm_panel.id, transaction_type='IN', quantity=50, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=wm_body.id, transaction_type='IN', quantity=60, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=wm_pump.id, transaction_type='IN', quantity=75, reference='Initial Stock', user_id=admin.id),
        
        # Cooler Parts
        RawMaterialTransaction(raw_material_id=cooler_motor.id, transaction_type='IN', quantity=90, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=cooler_pad.id, transaction_type='IN', quantity=200, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=cooler_tank.id, transaction_type='IN', quantity=70, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=cooler_body.id, transaction_type='IN', quantity=65, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=cooler_blower.id, transaction_type='IN', quantity=80, reference='Initial Stock', user_id=admin.id),
        
        # Dryer Parts
        RawMaterialTransaction(raw_material_id=dryer_motor.id, transaction_type='IN', quantity=60, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=dryer_drum.id, transaction_type='IN', quantity=50, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=dryer_heater.id, transaction_type='IN', quantity=55, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=dryer_body.id, transaction_type='IN', quantity=45, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=dryer_belt.id, transaction_type='IN', quantity=70, reference='Initial Stock', user_id=admin.id),
        
        # Common Parts
        RawMaterialTransaction(raw_material_id=power_cord.id, transaction_type='IN', quantity=300, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=screws.id, transaction_type='IN', quantity=500, reference='Initial Stock', user_id=admin.id),
        RawMaterialTransaction(raw_material_id=packaging.id, transaction_type='IN', quantity=250, reference='Initial Stock', user_id=admin.id),
    ]
    
    db.session.add_all(initial_stock)
    db.session.commit()
    
    # Add some sample production entries from previous days
    sample_date1 = date.today() - timedelta(days=2)
    sample_date2 = date.today() - timedelta(days=1)
    
    prod1 = ProductionEntry(
        production_date=sample_date1,
        product_model_id=wm_model1.id,
        quantity_produced=5,
        worker_id=workers[0].id,
        user_id=staff1.id,
        notes='Sample production'
    )
    
    prod2 = ProductionEntry(
        production_date=sample_date2,
        product_model_id=cooler_model1.id,
        quantity_produced=8,
        worker_id=workers[1].id,
        user_id=staff1.id,
        notes='Sample production'
    )
    
    db.session.add_all([prod1, prod2])
    db.session.commit()
    
    # Create Suppliers
    from app.models.business_partners import Supplier, Customer, PurchaseOrder, SalesOrder
    
    suppliers = [
        Supplier(
            name='ABC Electronics Supplies',
            company_name='ABC Electronics Pvt Ltd',
            contact_person='Ali Ahmed',
            phone='+92-321-1234567',
            email='ali@abcelectronics.pk',
            address='Plot 123, Industrial Area',
            city='Karachi',
            country='Pakistan',
            payment_terms='Net 30 days',
            credit_limit=500000,
            rating=5,
            notes='Reliable supplier for motors and electronic components'
        ),
        Supplier(
            name='Global Parts Trading',
            company_name='Global Parts Trading LLC',
            contact_person='Hassan Khan',
            phone='+92-321-9876543',
            email='hassan@globalparts.pk',
            address='Shop 45, Hardware Market',
            city='Lahore',
            country='Pakistan',
            payment_terms='Net 15 days',
            credit_limit=300000,
            rating=4,
            notes='Good prices for body shells and drums'
        ),
        Supplier(
            name='Tech Components',
            company_name='Tech Components (Pvt) Ltd',
            contact_person='Bilal Raza',
            phone='+92-333-5551234',
            email='bilal@techcomp.pk',
            address='456 Main Boulevard',
            city='Islamabad',
            country='Pakistan',
            payment_terms='Net 30 days',
            credit_limit=400000,
            rating=5,
            notes='Premium quality control panels and electronics'
        ),
        Supplier(
            name='Pakistan Packaging Co',
            company_name='Pakistan Packaging Company',
            contact_person='Imran Shah',
            phone='+92-300-7778888',
            email='imran@pakpack.pk',
            address='Industrial Estate, Sector 12',
            city='Faisalabad',
            country='Pakistan',
            payment_terms='Net 7 days',
            credit_limit=150000,
            rating=4,
            notes='Packaging boxes and materials supplier'
        ),
    ]
    
    db.session.add_all(suppliers)
    db.session.commit()
    
    # Create Customers
    customers = [
        Customer(
            name='Metro Electronics',
            company_name='Metro Electronics Chain',
            contact_person='Ahmed Malik',
            phone='+92-21-35551111',
            email='ahmed@metroelectronics.pk',
            address='Main Market, Gulshan',
            city='Karachi',
            country='Pakistan',
            customer_type='Wholesale',
            payment_terms='Net 45 days',
            credit_limit=1000000,
            notes='Large retail chain, regular orders'
        ),
        Customer(
            name='Home Appliances Mart',
            company_name='Home Appliances Mart',
            contact_person='Fatima Khan',
            phone='+92-42-35556666',
            email='fatima@homemart.pk',
            address='MM Alam Road',
            city='Lahore',
            country='Pakistan',
            customer_type='Retail',
            payment_terms='Net 30 days',
            credit_limit=500000,
            notes='Growing retail business'
        ),
        Customer(
            name='Distributors Hub',
            company_name='National Distributors Hub',
            contact_person='Usman Tariq',
            phone='+92-51-5559999',
            email='usman@distrhub.pk',
            address='Blue Area, F-7',
            city='Islamabad',
            country='Pakistan',
            customer_type='Distributor',
            payment_terms='Net 60 days',
            credit_limit=2000000,
            notes='Major distributor covering northern region'
        ),
        Customer(
            name='City Electronics',
            company_name='City Electronics Store',
            contact_person='Sana Akhtar',
            phone='+92-333-1112222',
            email='sana@cityelectronics.pk',
            address='Saddar Bazaar',
            city='Rawalpindi',
            country='Pakistan',
            customer_type='Retail',
            payment_terms='Net 30 days',
            credit_limit=300000,
            notes='Local retailer, consistent orders'
        ),
        Customer(
            name='Appliance World',
            company_name='Appliance World Pvt Ltd',
            contact_person='Kamran Ali',
            phone='+92-300-4445555',
            email='kamran@applianceworld.pk',
            address='Gulberg Plaza',
            city='Multan',
            country='Pakistan',
            customer_type='Wholesale',
            payment_terms='Net 45 days',
            credit_limit=800000,
            notes='Wholesale buyer, bulk orders'
        ),
    ]
    
    db.session.add_all(customers)
    db.session.commit()
    
    # Process production (deduct materials and add finished goods)
    for prod in [prod1, prod2]:
        # Get recipe
        recipes = ProductRecipe.query.filter_by(product_model_id=prod.product_model_id).all()
        
        # Deduct raw materials
        for recipe in recipes:
            total_qty = recipe.quantity_per_unit * prod.quantity_produced
            transaction = RawMaterialTransaction(
                raw_material_id=recipe.raw_material_id,
                transaction_type='PRODUCTION',
                quantity=total_qty,
                reference=f'Production #{prod.id}',
                user_id=prod.user_id,
                transaction_date=datetime.combine(prod.production_date, datetime.min.time())
            )
            db.session.add(transaction)
        
        # Add finished goods
        finished_goods = FinishedGoodsStock(
            product_model_id=prod.product_model_id,
            transaction_type='IN',
            quantity=prod.quantity_produced,
            reference=f'Production #{prod.id}',
            user_id=prod.user_id,
            transaction_date=datetime.combine(prod.production_date, datetime.min.time())
        )
        db.session.add(finished_goods)
    
    db.session.commit()
    
    print("Database seeded successfully!")
