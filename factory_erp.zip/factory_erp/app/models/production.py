from app import db
from datetime import datetime

class Worker(db.Model):
    __tablename__ = 'workers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    employee_id = db.Column(db.String(50), unique=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    production_entries = db.relationship('ProductionEntry', backref='worker', lazy=True)
    
    def __repr__(self):
        return f'<Worker {self.name}>'

class ProductionEntry(db.Model):
    __tablename__ = 'production_entries'
    
    id = db.Column(db.Integer, primary_key=True)
    production_date = db.Column(db.Date, nullable=False)
    product_model_id = db.Column(db.Integer, db.ForeignKey('product_models.id'), nullable=False)
    quantity_produced = db.Column(db.Integer, nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('workers.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))  # User who entered the data
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)
    
    # Relationships
    user = db.relationship('User')
    
    def __repr__(self):
        return f'<ProductionEntry {self.production_date} - {self.quantity_produced}>'

class FinishedGoodsStock(db.Model):
    __tablename__ = 'finished_goods_stock'
    
    id = db.Column(db.Integer, primary_key=True)
    product_model_id = db.Column(db.Integer, db.ForeignKey('product_models.id'), nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # IN (from production), OUT (dispatch)
    quantity = db.Column(db.Integer, nullable=False)
    transaction_date = db.Column(db.DateTime, default=datetime.utcnow)
    reference = db.Column(db.String(200))  # Reference to production entry or dispatch order
    notes = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    user = db.relationship('User')
    
    def __repr__(self):
        return f'<FinishedGoodsStock {self.transaction_type} {self.quantity}>'
    
    @staticmethod
    def get_current_stock(product_model_id):
        """Calculate current stock for a product model"""
        transactions = FinishedGoodsStock.query.filter_by(product_model_id=product_model_id).all()
        stock = 0
        for t in transactions:
            if t.transaction_type == 'IN':
                stock += t.quantity
            elif t.transaction_type == 'OUT':
                stock -= t.quantity
        return stock
