from app import db
from datetime import datetime

class RawMaterialCategory(db.Model):
    __tablename__ = 'raw_material_categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)  # WM Parts, Cooler Parts, Dryer Parts
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    raw_materials = db.relationship('RawMaterial', backref='category', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<RawMaterialCategory {self.name}>'

class RawMaterial(db.Model):
    __tablename__ = 'raw_materials'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('raw_material_categories.id'), nullable=False)
    unit = db.Column(db.String(20), nullable=False)  # pcs, kg, meter, etc.
    low_stock_threshold = db.Column(db.Float, default=10)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    stock_transactions = db.relationship('RawMaterialTransaction', backref='raw_material', lazy=True)
    
    def get_current_stock(self):
        """Calculate current stock from all transactions"""
        transactions = RawMaterialTransaction.query.filter_by(raw_material_id=self.id).all()
        stock = 0
        for t in transactions:
            if t.transaction_type == 'IN':
                stock += t.quantity
            elif t.transaction_type == 'OUT':
                stock -= t.quantity
        return stock
    
    def is_low_stock(self):
        """Check if current stock is below threshold"""
        return self.get_current_stock() <= self.low_stock_threshold
    
    def __repr__(self):
        return f'<RawMaterial {self.name}>'

class RawMaterialTransaction(db.Model):
    __tablename__ = 'raw_material_transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    raw_material_id = db.Column(db.Integer, db.ForeignKey('raw_materials.id'), nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # IN, OUT, PRODUCTION
    quantity = db.Column(db.Float, nullable=False)
    transaction_date = db.Column(db.DateTime, default=datetime.utcnow)
    reference = db.Column(db.String(200))  # Reference to production entry or purchase order
    notes = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    user = db.relationship('User')
    
    def __repr__(self):
        return f'<RawMaterialTransaction {self.transaction_type} {self.quantity}>'
