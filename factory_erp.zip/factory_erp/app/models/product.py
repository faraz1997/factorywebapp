from app import db
from datetime import datetime

class ProductCategory(db.Model):
    __tablename__ = 'product_categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)  # Washing Machine, Cooler, Dryer
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    models = db.relationship('ProductModel', backref='category', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<ProductCategory {self.name}>'

class ProductModel(db.Model):
    __tablename__ = 'product_models'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('product_categories.id'), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    recipes = db.relationship('ProductRecipe', backref='product_model', lazy=True, cascade='all, delete-orphan')
    production_entries = db.relationship('ProductionEntry', backref='product_model', lazy=True)
    finished_goods = db.relationship('FinishedGoodsStock', backref='product_model', lazy=True)
    
    def __repr__(self):
        return f'<ProductModel {self.name}>'

class ProductRecipe(db.Model):
    __tablename__ = 'product_recipes'
    
    id = db.Column(db.Integer, primary_key=True)
    product_model_id = db.Column(db.Integer, db.ForeignKey('product_models.id'), nullable=False)
    raw_material_id = db.Column(db.Integer, db.ForeignKey('raw_materials.id'), nullable=False)
    quantity_per_unit = db.Column(db.Float, nullable=False)  # Quantity needed for 1 product
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    raw_material = db.relationship('RawMaterial', backref='recipes')
    
    def __repr__(self):
        return f'<ProductRecipe {self.product_model_id}-{self.raw_material_id}>'
