@echo off
REM Factory ERP System - Windows Installation Script

echo ==========================================
echo Factory ERP System - Installation
echo ==========================================
echo.

echo Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [X] Python not found! Please install Python 3.8 or higher
    echo     Download from: https://www.python.org/downloads/
    pause
    exit /b 1
)
echo [OK] Python detected

echo.
echo Installing dependencies...
pip install Flask Flask-SQLAlchemy Flask-Login

if errorlevel 1 (
    echo [X] Failed to install dependencies
    echo     Try manually: pip install Flask Flask-SQLAlchemy Flask-Login
    pause
    exit /b 1
)
echo [OK] Dependencies installed

echo.
echo ==========================================
echo Installation Complete!
echo ==========================================
echo.
echo To start the application:
echo   1. Open command prompt in this folder
echo   2. Run: python run.py
echo   3. Open http://localhost:5000 in your browser
echo.
echo Login Credentials:
echo   Admin: admin / admin123
echo   Staff: staff1 / staff123
echo.
echo For more information, see README.md or QUICK_START.md
echo ==========================================
echo.
pause
